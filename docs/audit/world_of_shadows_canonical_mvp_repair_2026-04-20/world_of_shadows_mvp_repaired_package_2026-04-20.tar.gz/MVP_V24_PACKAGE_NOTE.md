# MVP v24 Package Note

`world_of_shadows_mvp_v24_lean_finishable` is the curated successor to the broader v23 package.

## Packaging decision

The package is optimized for:

- low ballast,
- high implementation leverage,
- lower drift risk,
- and easier controlled completion.

It is **not** optimized for preserving every historical artifact.

## Kept because they matter at end-state

The package keeps the service and governance surfaces that are expected to matter in the final implementation path:

- backend
- world-engine
- frontend
- administration-tool
- writers-room
- ai_stack
- story_runtime_core
- content
- tools / MCP surface
- core and curated docs
- MVP reference scaffold
- FY governance suites
- validation and governance-cycle scripts

## Removed because they were ballast for this purpose

Removed materials were mainly:

- promotional/export material,
- heavy archive/history areas,
- auxiliary side-workflow surfaces,
- and materials that did not materially improve runtime completion.

## Lean governance anchors now included

To keep the curated package governable, v24 now carries a small set of replacement anchors instead of the removed broad historical trees:

- `docs/dev/contracts/normative-contracts-index.md`
- `docs/operations/OPERATIONAL_GOVERNANCE_RUNTIME.md`
- `governance/V24_SOURCE_PRESERVATION_LEDGER.md`
- `validation/V24_GOVERNANCE_ATTACHMENT_REPORT.md`

## Canonical reading route after repair

The package now distinguishes more clearly between:

- canonical experience definition under `docs/MVPs/world_of_shadows_canonical_mvp/`,
- normative GoC slice contracts under `docs/MVPs/MVP_VSL_And_GoC_Contracts/`,
- support and audience docs under `docs/start-here/`, `docs/user/`, `docs/admin/`, and `docs/technical/`,
- and audit / evidence bundles under `docs/audit/`, `validation/`, and `evidence/raw_test_outputs/`.

The active proof-aware review bundle for this repaired package lives at:

- `docs/audit/world_of_shadows_canonical_mvp_repair_2026-04-20/`

## Important truth boundary

This package still does **not** claim that the whole platform is already production-ready.
It claims that the package is better suited for **completing** the implementation without dragging unnecessary ballast.
