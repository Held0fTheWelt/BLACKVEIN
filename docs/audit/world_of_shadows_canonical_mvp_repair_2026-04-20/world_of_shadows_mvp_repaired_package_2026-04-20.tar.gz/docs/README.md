# WorldOfShadows documentation

Audience-first documentation entrypoint.

## Canonical MVP route

- Canonical experience definition: [`docs/MVPs/README.md`](MVPs/README.md)
- Primary canonical spine: [`docs/MVPs/world_of_shadows_canonical_mvp/README.md`](MVPs/world_of_shadows_canonical_mvp/README.md)
- Active repair and review bundle: [`docs/audit/world_of_shadows_canonical_mvp_repair_2026-04-20/`](audit/world_of_shadows_canonical_mvp_repair_2026-04-20/)

## Start here (everyone)

- Plain-language orientation: [`docs/start-here/README.md`](start-here/README.md)
- Master index: [`docs/INDEX.md`](INDEX.md)
- Full glossary: [`docs/reference/glossary.md`](reference/glossary.md)
- Short glossary: [`docs/start-here/glossary.md`](start-here/glossary.md)
- Doc registry: [`docs/reference/documentation-registry.md`](reference/documentation-registry.md)

## Audience roots

- **Users:** [`docs/user/README.md`](user/README.md)
- **Administrators / operators:** [`docs/admin/README.md`](admin/README.md)
- **Developers:** [`docs/dev/README.md`](dev/README.md) — lean redirect layer retained for governance-stable paths
- **Technical system (architecture, AI, runtime):** [`docs/technical/README.md`](technical/README.md)
- **Stakeholder slides:** [`docs/presentations/`](presentations/)
- **ADRs:** [`docs/governance/README.md`](governance/README.md)

## Optional static site (MkDocs)

From repository root (after `pip install -r requirements-docs.txt`):

```bash
python -m mkdocs serve
```

Build output is gitignored at `/site/` (see `mkdocs.yml`). CI builds on changes to `docs/`, `mkdocs.yml`, and `requirements-docs.txt`.

## Legacy and evidence

- **Archived/tombstoned carry-forward surfaces:** [`docs/archive/`](archive/) — lean notes only, not the full historical archive
- **Audit and repair bundles:** [`docs/audit/`](audit/) — active review package plus preserved prior consolidation/re-audit bundles
- **Executable and governance evidence:** `validation/`, `governance/`, and `evidence/raw_test_outputs/`

## Consolidation and carry-forward record

See [`governance/V24_SOURCE_PRESERVATION_LEDGER.md`](../governance/V24_SOURCE_PRESERVATION_LEDGER.md) for the original-repository → v24 mapping and intentional exclusions.
