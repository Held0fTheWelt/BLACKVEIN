# MVP Documentation Map

This folder carries the active MVP definition surfaces for World of Shadows.
Use it when you need the product canon, the slice contracts, or the package's proof-aware reading route.

## Primary reading route

- Canonical experience definition: [`world_of_shadows_canonical_mvp/README.md`](world_of_shadows_canonical_mvp/README.md)
- GoC normative slice contracts: [`MVP_VSL_And_GoC_Contracts/`](MVP_VSL_And_GoC_Contracts/)
- Active repair and review bundle: [`../audit/world_of_shadows_canonical_mvp_repair_2026-04-20/`](../audit/world_of_shadows_canonical_mvp_repair_2026-04-20/)

## Authority map

| Path family | Role | Can define product truth? | Precedence note |
|---|---|---|---|
| `docs/MVPs/world_of_shadows_canonical_mvp/` | Canonical experience-definition spine | Yes | Primary human-readable MVP route |
| `docs/MVPs/MVP_VSL_And_GoC_Contracts/` | Normative GoC slice contracts | Yes | Primary normative home for GoC contract language |
| `content/modules/god_of_carnage/` | Canonical authored source for the active slice | Yes | Authoring truth for GoC content and direction assets |
| `docs/CANONICAL_TURN_CONTRACT_GOC.md`, `docs/VERTICAL_SLICE_CONTRACT_GOC.md`, `docs/GATE_SCORING_POLICY_GOC.md` | Compatibility mirrors / legacy-stable entrypoints | Not as an independent lane | If wording diverges, the `docs/MVPs/MVP_VSL_And_GoC_Contracts/` copies win |
| `mvp/` | Preserved historical MVP family plus reference scaffold | No | Truth-bearing source lineage, but not the active package reading spine |
| `docs/audit/`, `validation/`, `evidence/raw_test_outputs/` | Audit, proof, and carried-forward evidence | No | Evidence may support claims, but does not replace canon |
| `backend/var/`, `runtime_data/`, session mirrors, cached observations | Runtime or environment payload/residue | No | Useful for diagnosis or continuity, never a normative source |

## Reading rule

Read the package in this order when you need a full truth-aware picture:

1. Canonical experience spine under [`world_of_shadows_canonical_mvp/`](world_of_shadows_canonical_mvp/README.md)
2. GoC normative contracts under [`MVP_VSL_And_GoC_Contracts/`](MVP_VSL_And_GoC_Contracts/)
3. Repair bundle under [`../audit/world_of_shadows_canonical_mvp_repair_2026-04-20/`](../audit/world_of_shadows_canonical_mvp_repair_2026-04-20/)

Everything else should be read as support, evidence, implementation, or preserved historical source unless it explicitly declares a stronger role.
