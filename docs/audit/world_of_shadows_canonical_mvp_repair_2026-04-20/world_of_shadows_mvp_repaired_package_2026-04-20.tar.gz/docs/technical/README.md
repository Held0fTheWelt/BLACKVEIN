# Technical documentation

Active **system** documentation for World of Shadows: architecture, runtime authority, AI/RAG, integrations (MCP, LangGraph, LangChain), content pipeline, and technical reference material.

**Audience:** engineers, operators who need implementation truth, and technical integrators.

**Not in this tree:** contributor workflow (see [`docs/dev/`](../dev/README.md)), player guides ([`docs/user/`](../user/README.md)), or short orientation ([`docs/start-here/`](../start-here/README.md)).

## Contents

| Area | Path |
|------|------|
| Architecture & boundaries | [`architecture/`](architecture/) |
| Runtime & sessions | [`runtime/`](runtime/) |
| AI & retrieval | [`ai/`](ai/) |
| Integrations | [`integration/`](integration/) |
| Content & publishing | [`content/`](content/) |
| Reference (tests, indexes) | [`reference/`](reference/) |
| Technical operations detail | [`operations/`](operations/) |

## Normative contracts (slice / module)

High-change contracts remain discoverable from [`docs/dev/contracts/normative-contracts-index.md`](../dev/contracts/normative-contracts-index.md).
The primary normative home for GoC slice contracts is [`docs/MVPs/MVP_VSL_And_GoC_Contracts/`](../MVPs/MVP_VSL_And_GoC_Contracts/); root-level `docs/*_GOC.md` files are compatibility mirrors rather than a second contract lane.

## Legacy location

Older files formerly under `docs/architecture/` are either **moved here**, represented by lean tombstones under [`docs/archive/architecture-legacy/`](../archive/architecture-legacy/), or superseded by a single canonical page per topic. Current carry-forward mapping is recorded in [`governance/V24_SOURCE_PRESERVATION_LEDGER.md`](../../governance/V24_SOURCE_PRESERVATION_LEDGER.md).
