# Audit And Repair Bundles

This folder now contains the active documentation review bundles for the curated World of Shadows MVP package.

## Read first

- Active repair package: [`world_of_shadows_canonical_mvp_repair_2026-04-20/`](world_of_shadows_canonical_mvp_repair_2026-04-20/)
- Current canonical MVP spine: [`../MVPs/world_of_shadows_canonical_mvp/README.md`](../MVPs/world_of_shadows_canonical_mvp/README.md)

## Historical support bundles kept visible

- [`world_of_shadows_canonical_mvp_consolidation_2026-04-20/`](world_of_shadows_canonical_mvp_consolidation_2026-04-20/)
- [`world_of_shadows_canonical_mvp_reaudit_2026-04-20/`](world_of_shadows_canonical_mvp_reaudit_2026-04-20/)
- `world_of_shadows_canonical_mvp_*_extension_2026-04-20/`
- `world_of_shadows_canonical_mvp_supplied_archive_audit_2026-04-20/`

Those bundles remain reachable because they are truth-bearing evidence.
They are no longer the preferred first-stop review route once the repair package exists.

## Related evidence outside this tree

- [FY baseline summary](../../governance/FY_BASELINE_SUMMARY.md)
- [Validation report](../../validation/V24_PACKAGE_VALIDATION.md)
- [Governance attachment report](../../validation/V24_GOVERNANCE_ATTACHMENT_REPORT.md)
- [Touched governance link check](../../validation/V24_TOUCHED_GOVERNANCE_LINK_CHECK.md)

For excluded original-repository audit layers and their carry-forward treatment, see [`../../governance/V24_SOURCE_PRESERVATION_LEDGER.md`](../../governance/V24_SOURCE_PRESERVATION_LEDGER.md).
