# World of Shadows canonical MVP repair bundle

This folder is the active reviewer-facing repair package for the current World of Shadows MVP arrangement.

It does three things at once:

- records what was actually repaired in the package,
- separates intended scope, implemented reality, carried-forward evidence, newly verified evidence, and unresolved proof burden,
- and gives a later reviewer one legible route instead of forcing them to reconstruct the repair from multiple older audit lanes.

## Read in this order

1. [`A_MASTER_REPAIR_REPORT.md`](A_MASTER_REPAIR_REPORT.md)
2. [`B_REPAIR_CLAIM_EVIDENCE_MATRIX.md`](B_REPAIR_CLAIM_EVIDENCE_MATRIX.md)
3. [`D_REMAINING_TENSION_RECORD.md`](D_REMAINING_TENSION_RECORD.md)
4. [`E_REVIEWER_CHECKLIST.md`](E_REVIEWER_CHECKLIST.md)
5. [`F_REPAIRED_CANONICAL_MVP_DOCUMENT_SET/README.md`](F_REPAIRED_CANONICAL_MVP_DOCUMENT_SET/README.md)
6. [`G_FINAL_REPAIRED_ARCHIVE_RECORD.md`](G_FINAL_REPAIRED_ARCHIVE_RECORD.md)
7. [`H_FINAL_REPAIRED_EXPERIENCE_JUDGMENT.md`](H_FINAL_REPAIRED_EXPERIENCE_JUDGMENT.md)

## Package role

This bundle supersedes earlier consolidation/re-audit bundles as the **preferred first-stop review package**.
Those earlier bundles remain preserved under `docs/audit/` as truth-bearing support and historical context.

The exported reviewer archive for this repaired subset is:

- `world_of_shadows_mvp_repaired_package_2026-04-20.tar.gz`
