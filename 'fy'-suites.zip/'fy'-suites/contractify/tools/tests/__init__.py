"""Tests for Contractify tools."""
